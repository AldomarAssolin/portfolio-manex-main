<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use DB;

class PostSeeder extends Seeder {
    public function run(): void {
        $faker = Faker::create();
        for ($i=0; $i<10; $i++) {
            DB::table('posts')->insert([
                'id_usuario' => 1,
                'titulo' => $faker->sentence(5),
                'conteudo' => $faker->paragraph(5),
                'status' => $faker->randomElement(['rascunho','publicado']),
                'created_at' => now()
            ]);
        }
    }
}