<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use DB;

class UsuarioSeeder extends Seeder {
    public function run(): void {
        DB::table('usuarios')->insert([
            [
                'nome' => 'Administrador',
                'email' => 'admin@example.com',
                'senha' => Hash::make('password'),
                'cargo' => 'admin',
                'bio' => 'Usuário administrador padrão',
                'created_at' => now()
            ]
        ]);
    }
}